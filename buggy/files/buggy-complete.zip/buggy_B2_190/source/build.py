from pathlib import Path
import math,json,csv,collections
import numpy as np
import trimesh
OUT=Path(__file__).resolve().parents[1]; OUT.mkdir(exist_ok=True)
P=dict(version='B2-190 v0.1',date='22.10.2026',occupants=2,person_mass=80,person_height=1900,front_axle_x=350,rear_axle_x=2550,front_track=1400,rear_track=1300,wheel_d=576,wheel_w=175,frame_z=350,cabin_half_width=650,main_hoop_x=2050,main_hoop_z=1750,bend_R=150)
parts=[]; comps=[]
colors={'frame':[242,145,28,255],'cage':[255,170,35,255],'secondary':[214,111,25,255],'wheels':[35,41,49,255],'alloy':[153,166,179,255],'seat':[52,69,81,255],'engine':[50,85,112,255],'power':[145,93,189,255],'suspension':[104,119,129,255],'floor':[118,136,146,255],'human':[92,171,159,140]}
def V(p): return np.array(p,dtype=float)
def length(a,b):return float(np.linalg.norm(V(b)-V(a)))
def add(id,sec,a,b,name,exact=None):
 l=length(a,b); blank=exact if exact else math.ceil((l+60)/5)*5
 parts.append(dict(id=id,section=sec,name=name,a=list(a),b=list(b),length=round(l,2),blank=int(blank),kind='straight',finish='90°; размер между торцами' if exact else 'припуск; торцы подогнать по узлу'))
def pair(id,sec,a,b,name,exact=None):
 for side,s in [('L',-1),('R',1)]:add(id+side,sec,[a[0],s*a[1],a[2]],[b[0],s*b[1],b[2]],name,exact)
# Frame datum points; left and right mirror. Dimensions refer to tube centrelines unless stated.
stations=[(0,350,350),(650,350,350),(900,650,350),(2050,650,350),(2300,400,550),(3000,400,550)]
for i,(a,b) in enumerate(zip(stations,stations[1:]),1):pair(f'A{i:02d}','40x40x2',a,b,'Лонжерон / переход')
for i,(x,w,z) in enumerate([(0,350,350),(500,350,350),(900,650,350),(1450,650,350),(1850,650,350),(2050,650,350),(2300,400,550),(2900,400,550),(3000,400,550)],11):
 add(f'A{i}','40x40x2',(x,-w+20,z),(x,w-20,z),'Поперечина между лонжеронами',2*w-40)
# Side structure
pair('B01','30x30x2',(900,650,700),(2050,650,700),'Верх борта')
for j,x in enumerate([900,1450,2050],2):pair(f'B{j:02d}','30x30x2',(x,650,370),(x,650,685),'Стойка борта',315)
pair('B05','30x30x2',(900,650,370),(1450,650,700),'Диагональ борта, передняя')
pair('B06','30x30x2',(1450,650,370),(2050,650,700),'Диагональ борта, задняя')
add('B07','30x30x2',(900,-630,350),(1450,630,350),'Диагональ пола, передняя')
add('B08','30x30x2',(1450,630,350),(2050,-630,350),'Диагональ пола, задняя')
pair('B09','30x30x2',(2250,380,720),(2950,380,720),'Продольная опора моторной площадки')
for j,x in enumerate([2250,2950],10): add(f'B{j}','30x30x2',(x,-380,720),(x,380,720),'Поперечина моторной площадки')
for j,(x,z) in enumerate([(2300,570),(2900,570)],12):pair(f'B{j}','30x30x2',(x,380,z),(x,380,705),'Стойка моторной площадки',135)
pair('B14','30x30x2',(2300,380,550),(2950,380,720),'Диагональ моторной площадки')
for j,x in enumerate([2350,2850],15):add(f'B{j}', '30x30x2',(x,-365,720),(x,365,720),'Опора под моторной плитой',730)
# Light supports, explicitly not seat belt anchors
for j,x in enumerate([600,1050],1):add(f'C{j:02d}','25x25x2',(x,-320,410),(x,320,410),'Опора панели / площадки педалей')
add('C03','25x25x2',(1050,-620,850),(1050,620,850),'Поперечина панели приборов')
pair('C04','25x25x2',(900,650,700),(1050,620,850),'Опора панели')
# Form one-piece bent hoops in a plane spanned by up vector and transverse Y.
def hoop(id,base,top,half,R):
 base=V(base);top=V(top); up=(top-base)/np.linalg.norm(top-base);H=np.linalg.norm(top-base)
 pts=[base+V([0,-half,0]),base+up*(H-R)+V([0,-half,0])]
 # first arc from left vertical to top horizontal
 c=base+up*(H-R)+V([0,-half+R,0])
 for t in np.linspace(0,math.pi/2,19)[1:]: pts.append(c+V([0,-R*math.cos(t),0])+up*R*math.sin(t))
 pts.append(top+V([0,half-R,0]))
 c=base+up*(H-R)+V([0,half-R,0])
 for t in np.linspace(0,math.pi/2,19)[1:]:pts.append(c+V([0,R*math.sin(t),0])+up*R*math.cos(t))
 pts.append(base+V([0,half,0]))
 developed=2*(H-R)+math.pi*R+2*(half-R)
 parts.append(dict(id=id,section='45x3',name='Главная дуга' if id=='D01' else 'Передняя наклонная дуга',a=pts[0].tolist(),b=pts[-1].tolist(),length=round(developed,2),blank=int(math.ceil((developed+120)/10)*10),kind='hoop',path=[p.tolist() for p in pts],base=base.tolist(),top=top.tolist(),half=half,R=R,H=H,finish='2 гиба 90°; R по оси 150; торцы подрезать после гибки'))
hoop('D01',(2050,0,370),(2050,0,1750),650,150)
hoop('D02',(900,0,715),(1200,0,1600),650,150)
pair('D03','45x3',(1200,500,1600),(2050,500,1750),'Продольная связь крыши')
pair('D04','45x3',(2050,500,1750),(2950,400,550),'Задний подкос')
add('D05','45x3',(2050,-650,410),(2050,500,1750),'Диагональ главной дуги')
add('D06','45x3',(1200,-500,1600),(2050,500,1750),'Диагональ крыши')
add('D07','45x3',(2050,-650,1100),(2050,650,1100),'Поперечная связь; высота ремней по инструкции')
# Geometry helpers
scene=trimesh.Scene(); meshes=[]
def save_mesh(name,mesh,group,col=None):
 mesh.visual.vertex_colors=col or colors[group];scene.add_geometry(mesh,node_name=name,geom_name=name);meshes.append(mesh)
 comps.append(dict(name=name,group=group,vertices=np.round(mesh.vertices,2).tolist(),faces=mesh.faces.tolist(),color=(col or colors[group])[:3]))
def basis(a,b):
 z=(V(b)-V(a)); z=z/np.linalg.norm(z); ref=V([0,0,1])
 if abs(np.dot(z,ref))>.95:ref=V([0,1,0])
 x=np.cross(ref,z);x/=np.linalg.norm(x);y=np.cross(z,x)
 return x,y,z

def tube_mesh(a,b,size,wall=0,round_=False,n=12):
 x,y,z=basis(a,b);L=length(a,b)
 if round_:
  t=np.linspace(0,2*math.pi,n,endpoint=False);ring=np.array([np.cos(t),np.sin(t)]).T*size/2
 else:ring=np.array([[-1,-1],[1,-1],[1,1],[-1,1]])*size/2
 inner=ring*(size-2*wall)/size if wall else None
 rings=[ring,ring] if inner is None else [ring,ring,inner,inner];verts=[]
 for i,r in enumerate(rings):
  o=V(a) if i%2==0 else V(b)
  verts.extend([o+x*p[0]+y*p[1] for p in r])
 N=len(ring);faces=[]
 for i in range(N):
  j=(i+1)%N;faces.extend([[i,j,N+j],[i,N+j,N+i]])
  if inner is not None:
   faces.extend([[2*N+i,3*N+j,2*N+j],[2*N+i,3*N+i,3*N+j],[i,2*N+j,j],[i,2*N+i,2*N+j],[N+i,N+j,3*N+j],[N+i,3*N+j,3*N+i]])
 if inner is None:
  for i in range(1,N-1):faces.extend([[0,i+1,i],[N,N+i,N+i+1]])
 m=trimesh.Trimesh(vertices=verts,faces=faces,process=True);m.fix_normals();return m

def bent_mesh(path,d=45,t=3):
 path=np.array(path);N=12;verts=[]
 normal=np.cross(path[1]-path[0],path[3]-path[1]);normal=normal/np.linalg.norm(normal)
 for i,p in enumerate(path):
  tang=path[min(i+1,len(path)-1)]-path[max(0,i-1)];tang/=np.linalg.norm(tang);u=np.cross(tang,normal);u/=np.linalg.norm(u)
  for r in [d/2,d/2-t]:
   verts.extend([p+r*(math.cos(a)*normal+math.sin(a)*u) for a in np.linspace(0,2*math.pi,N,endpoint=False)])
 faces=[]
 for k in range(len(path)-1):
  for j in range(N):
   q=(j+1)%N
   for inner in [0,1]:
    a=k*2*N+inner*N+j;b=k*2*N+inner*N+q;c=(k+1)*2*N+inner*N+q;e=(k+1)*2*N+inner*N+j
    faces.extend([[a,b,c],[a,c,e]])
 for k in [0,len(path)-1]:
  for j in range(N):
   q=(j+1)%N;a=k*2*N+j;b=k*2*N+q;c=k*2*N+N+q;d0=k*2*N+N+j
   faces.extend([[a,b,c],[a,c,d0]])
 m=trimesh.Trimesh(vertices=verts,faces=faces,process=True);m.fix_normals();return m
for p in parts:
 sec=p['section'];size=float(sec.split('x')[0]);wall=float(sec.split('x')[-1]);round_=sec=='45x3'
 save_mesh(p['id'],bent_mesh(p['path']) if p['kind']=='hoop' else tube_mesh(p['a'],p['b'],size,wall,round_), 'cage' if round_ else ('frame' if sec=='40x40x2' else 'secondary'))
frame_mesh_count=len(meshes)
def box(name,center,dims,group,rotation=None):
 m=trimesh.creation.box(dims)
 if rotation is not None:m.apply_transform(trimesh.transformations.rotation_matrix(math.radians(rotation[0]),rotation[1]))
 m.apply_translation(center);save_mesh(name,m,group)
def rod(name,a,b,d,group):save_mesh(name,tube_mesh(a,b,d,0,True,16),group)
def sphere(name,c,r,group,scale=None):
 m=trimesh.creation.icosphere(subdivisions=2,radius=r)
 if scale is not None:m.apply_scale(scale)
 m.apply_translation(c);save_mesh(name,m,group)
# Four wheels, tyre/rim illustration uses annular section.
for x,track in [(350,1400),(2550,1300)]:
 for s in [-1,1]:
  y=s*track/2
  save_mesh(f'Tyre_{x}_{s}',tube_mesh((x,y-87.5,288),(x,y+87.5,288),576,120,True,48),'wheels')
  save_mesh(f'Rim_{x}_{s}',tube_mesh((x,y-76,288),(x,y+76,288),330,20,True,36),'alloy')
  rod(f'Hub_{x}_{s}',(x,y-80,288),(x,y+80,288),100,'alloy')
  for a in range(0,360,60):
   r=math.radians(a);rod(f'Spoke_{x}_{s}_{a}',(x,y+s*65,288),(x+150*math.cos(r),y+s*65,288+150*math.sin(r)),22,'alloy')
# Solid axle is real beam concept, not independent halfshafts.
rod('REAR_SOLID_AXLE',(2550,-595,288),(2550,595,288),75,'suspension')
sphere('Differential_envelope',(2550,0,288),130,'suspension',scale=[1.15,1,.95])
rod('Pinion_envelope',(2340,0,288),(2550,0,288),70,'suspension')
# Suspension links shown only to communicate reserved space, not drilling coordinates.
for s in [-1,1]:
 for i,z in enumerate([300,455]):
  rod(f'Front_arm_{s}_{i}a',(200,s*350,z),(350,s*600,z-15),25,'suspension')
  rod(f'Front_arm_{s}_{i}b',(560,s*350,z),(350,s*600,z-15),25,'suspension')
 rod(f'Front_upright_{s}',(350,s*600,270),(350,s*600,470),38,'suspension')
 rod(f'Front_spring_{s}',(350,s*545,320),(500,s*350,630),65,'suspension')
 rod(f'Rear_lower_link_{s}',(2050,s*480,350),(2550,s*500,240),32,'suspension')
 rod(f'Rear_upper_link_{s}',(2200,s*220,540),(2550,s*240,365),30,'suspension')
 rod(f'Rear_spring_{s}',(2550,s*510,330),(2750,s*380,800),72,'suspension')
rod('Panhard_schematic',(2500,-430,530),(2550,500,320),28,'suspension')
# Floor plates; split because 1260-wide cabin exceeds a 1250 stock sheet.
box('Floor_left',(1465,-315,372),(1130,630,1.5),'floor')
box('Floor_right',(1465,315,372),(1130,630,1.5),'floor')
box('Foot_floor',(650,0,372),(500,660,1.5),'floor')
box('Firewall',(2115,0,850),(1.5,1300,960),'floor')
box('Engine_plate',(2600,80,737),(550,500,4),'floor')
for s in [-1,1]:
 y=s*320
 box(f'Seat_base_{s}',(1630,y,525),(500,480,110),'seat')
 box(f'Seat_back_{s}',(1860,y,900),(105,480,740),'seat',rotation=(12,[0,1,0]))
 box(f'Headrest_{s}',(1940,y,1310),(100,250,220),'seat')
# Envelope engine dimensions deliberately larger than typical 190F published bounds.
box('Engine_clearance',(2635,80,1000),(560,500,500),'engine')
box('Engine_fuel_tank',(2640,80,1270),(370,330,90),'engine')
rod('Engine_fan',(2400,-50,980),(2340,-50,980),260,'engine')
box('TRANSMISSION_RESERVED',(2260,0,650),(240,650,500),'power')
rod('Steering_column',(950,-320,600),(1280,-320,1000),28,'suspension')
# Wheel ring in a plane normal to steering shaft
save_mesh('Steering_wheel',tube_mesh((1268,-320,985),(1292,-320,1015),300,15,True,36),'seat')
# Scene output units: STL and STEP millimetres, glTF metres.
trimesh.util.concatenate(meshes).export(OUT/'buggy_B2_190_mm.stl')
trimesh.util.concatenate(meshes[:frame_mesh_count]).export(OUT/'frame_B2_190_mm.stl')
scene_m=scene.copy();scene_m.apply_scale(.001);scene_m.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]));scene_m.export(OUT/'buggy_B2_190.glb')
(OUT/'geometry.json').write_text(json.dumps(dict(parameters=P,parts=parts,components=comps),ensure_ascii=False),encoding='utf-8')
# Cut schedules, 3 mm kerf per blank and 10 mm crop at both stock ends.
bins={};summary=[]
for sec in ['40x40x2','30x30x2','25x25x2','45x3']:
 arr=sorted([p for p in parts if p['section']==sec],key=lambda p:p['blank'],reverse=True);bb=[]
 for p in arr:
  found=next((b for b in bb if b['used']+p['blank']+3<=5980),None)
  if found is None:found={'used':0,'parts':[]};bb.append(found)
  found['parts'].append(p['id']);found['used']+=p['blank']+3
 for b in bb:b['remaining']=5980-b['used']
 bins[sec]=bb
 massper={'40x40x2':2.33,'30x30x2':1.75,'25x25x2':1.40,'45x3':3.11}[sec]
 summary.append(dict(section=sec,net_m=round(sum(p['length'] for p in arr)/1000,3),blank_m=round(sum(p['blank'] for p in arr)/1000,3),bars=len(bb),buy_m=6*len(bb),net_kg=round(sum(p['length'] for p in arr)/1000*massper,1),buy_kg=round(6*len(bb)*massper,1)))
(OUT/'cutting_plan.json').write_text(json.dumps(dict(summary=summary,bins=bins),ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'cut_list.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['ID','Сечение','Название','X1','Y1','Z1','X2','Y2','Z2','Длина по оси/торцам мм','Заготовка мм','Торцы'])
 for p in parts:w.writerow([p['id'],p['section'],p['name'],*p['a'],*p['b'],p['length'],p['blank'],p['finish']])
print(json.dumps(summary,ensure_ascii=False,indent=2));print('parts',len(parts),'meshes',len(meshes))
