from pathlib import Path
OUT=Path(__file__).resolve().parents[1]
import bpy,math
from mathutils import Vector
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(OUT/'buggy_B2_190.glb'))
# glTF importer applies Y-up conversion; model was exported from Z-up by trimesh so importer restores Z-up.
import json
geo=json.load(open(str(OUT/'geometry.json')))
for comp in geo['components']:
 obj=bpy.data.objects.get(comp['name'])
 if obj and obj.type=='MESH':
  col=[((v/255+.055)/1.055)**2.4 if v/255>.04045 else v/255/12.92 for v in comp['color']]
  mat=bpy.data.materials.new(comp['name']+'_mat');mat.use_nodes=True
  bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*col,1);bs.inputs['Roughness'].default_value=.5
  if comp['group']=='alloy':bs.inputs['Metallic'].default_value=.7
  obj.data.materials.clear();obj.data.materials.append(mat)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.018));plane=bpy.context.object
mat=bpy.data.materials.new('ground');mat.diffuse_color=(.78,.82,.85,1);plane.data.materials.append(mat)
world=bpy.context.scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.8,.86,.94,1);world.node_tree.nodes['Background'].inputs[1].default_value=.6
for loc,power,size in [((0,-3,7),1300,5),((4,3,5),1100,4),((-3,1,3),500,3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);bpy.context.object.data.energy=power;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=size
bpy.ops.object.camera_add(location=(-3.6,-4.7,3.3));cam=bpy.context.object;target=Vector((1.4,0,.8));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=4.8
sc=bpy.context.scene;sc.camera=cam;sc.render.engine='CYCLES';sc.cycles.samples=48;sc.cycles.use_denoising=False;sc.render.resolution_x=1800;sc.render.resolution_y=1200;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG';sc.render.filepath=str(OUT/'preview_3D.png');sc.view_settings.view_transform='AgX';sc.render.threads_mode='FIXED';sc.render.threads=6
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'buggy_B2_190.blend'));bpy.ops.render.render(write_still=True)
