import cadquery as cq,json,math
from pathlib import Path
import numpy as np
out=Path(__file__).resolve().parents[1];data=json.loads((out/'geometry.json').read_text());ass=cq.Assembly(name='B2_190_CONCEPT_MM');count=0
for p in data['parts']:
 size=float(p['section'].split('x')[0]);wall=float(p['section'].split('x')[-1]);a=np.array(p['a']);b=np.array(p['b'])
 if p['kind']=='straight':
  d=b-a;l=np.linalg.norm(d);d=d/l;ref=np.array([0.,0.,1.])
  if abs(np.dot(d,ref))>.95:ref=np.array([0.,1.,0.])
  xx=np.cross(ref,d);xx/=np.linalg.norm(xx);plane=cq.Plane(origin=tuple(a),xDir=tuple(xx),normal=tuple(d))
  w=cq.Workplane(plane)
  w=w.circle(size/2).circle(size/2-wall) if p['section']=='45x3' else w.rect(size,size).rect(size-2*wall,size-2*wall)
  sh=w.extrude(float(l)).val()
 else:
  base=np.array(p['base']);top=np.array(p['top']);u=(top-base)/p['H'];Y=np.array([0.,1.,0.]);H=p['H'];R=p['R'];hw=p['half']
  pts=[base-hw*Y,base+u*(H-R)-hw*Y,top-(hw-R)*Y,top+(hw-R)*Y,base+u*(H-R)+hw*Y,base+hw*Y]
  c1=base+u*(H-R)-(hw-R)*Y;c2=base+u*(H-R)+(hw-R)*Y
  m1=c1+R/2**.5*(u-Y);m2=c2+R/2**.5*(u+Y)
  edges=[cq.Edge.makeLine(cq.Vector(*pts[0]),cq.Vector(*pts[1])),cq.Edge.makeThreePointArc(cq.Vector(*pts[1]),cq.Vector(*m1),cq.Vector(*pts[2])),cq.Edge.makeLine(cq.Vector(*pts[2]),cq.Vector(*pts[3])),cq.Edge.makeThreePointArc(cq.Vector(*pts[3]),cq.Vector(*m2),cq.Vector(*pts[4])),cq.Edge.makeLine(cq.Vector(*pts[4]),cq.Vector(*pts[5]))]
  path=cq.Wire.assembleEdges(edges);plane=cq.Plane(origin=tuple(pts[0]),normal=tuple(u),xDir=(0,1,0))
  sh=cq.Workplane(plane).circle(size/2).circle(size/2-wall).sweep(cq.Workplane('XY').add(path),isFrenet=True).val()
 if not sh.isValid():raise ValueError(p['id'])
 ass.add(sh,name=p['id'],color=cq.Color(1,.58,.08));count+=1
ass.save(str(out/'frame_B2_190.step'))
print('Valid STEP tube solids:',count)
