from pathlib import Path
import json,math
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A3,landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
import ezdxf
O=Path(__file__).resolve().parents[1];D=json.loads((O/'geometry.json').read_text());P=D['parts'];S=json.loads((O/'cutting_plan.json').read_text())
for nm,fn in [('DV','DejaVuSans.ttf'),('DVB','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(nm,'/usr/share/fonts/truetype/dejavu/'+fn))
W,H=landscape(A3);c=canvas.Canvas(str(O/'02_drawings_A3.pdf'),pagesize=(W,H));c.setTitle('B2-190 — размерные эскизы A3')
blue=HexColor('#24566c');orange=HexColor('#cf7d23');gray=HexColor('#697784')
def text(x,y,s,size=9,color=None):c.setFillColor(color or HexColor('#152d3b'));c.setFont('DV',size);c.drawString(x,y,str(s))
def page(n,title,sub='Все размеры в мм. ЭСКИЗ v0.1 — для компоновки и обмера агрегатов.'):
 c.setStrokeColor(blue);c.setLineWidth(.8);c.rect(24,24,W-48,H-48);text(40,H-51,'B2 / 190',22);text(230,H-48,title,18);text(40,H-75,sub,9)
 c.line(24,63,W-24,63);text(40,43,'2 места × 80 кг / рост до 1900 | 22.10.2026 | НЕ РАБОЧИЙ ЧЕРТЁЖ ДЛЯ СВАРКИ',8);text(W-160,43,f'Лист {n} / 7',9)
def line(x1,y1,x2,y2,color=blue,width=1,dash=None):
 c.setStrokeColor(color);c.setLineWidth(width);c.setDash(dash or []);c.line(x1,y1,x2,y2);c.setDash([])
def dimh(x1,x2,y,refy,label):
 for x in [x1,x2]:line(x,refy,x,y+5,gray,.4)
 line(x1,y,x2,y,blue,.5)
 for x,s in [(x1,1),(x2,-1)]:line(x,y,x+s*6,y+2,blue,.5);line(x,y,x+s*6,y-2,blue,.5)
 t=str(label);c.setFillColor(HexColor('#ffffff'));c.rect((x1+x2)/2-len(t)*2.8,y-2,len(t)*5.6,12,fill=1,stroke=0);text((x1+x2)/2-len(t)*2.6,y+1,t,8)
def dimv(y1,y2,x,refx,label):
 for y in [y1,y2]:line(refx,y,x+5,y,gray,.4)
 line(x,y1,x,y2,blue,.5)
 for y,s in [(y1,1),(y2,-1)]:line(x,y,x+2,y+s*6,blue,.5);line(x,y,x-2,y+s*6,blue,.5)
 c.saveState();c.translate(x-4,(y1+y2)/2);c.rotate(90);text(0,0,label,8);c.restoreState()
def render(proj,ox,oy,scale,groups=None,labels=False,tyres=False):
 def xy(pt):return ox+pt[proj[0]]*scale,oy+pt[proj[1]]*scale
 for p in P:
  if groups and p['section'] not in groups:continue
  ps=p.get('path',[p['a'],p['b']]);sz=float(p['section'].split('x')[0]);col=orange if p['section']=='45x3' else blue
  for a,b in zip(ps,ps[1:]):
   x,y=xy(a);xx,yy=xy(b);line(x,y,xx,yy,col,max(.6,sz*scale*.5))
  if labels:
   a,b=ps[0],ps[-1];x,y=xy([(a[i]+b[i])/2 for i in range(3)]);text(x+3,y+3,p['id'],6)
 if tyres:
  c.setLineWidth(1);c.setStrokeColor(gray)
  for x,track in [(350,1400),(2550,1300)]:
   for s in [-1,1]:
    y=s*track/2
    if proj==(0,2):
     cx,cy=xy([x,y,288]);c.circle(cx,cy,288*scale);c.circle(cx,cy,165*scale)
    elif proj==(0,1):
     cx,cy=xy([x,y,288]);c.rect(cx-288*scale,cy-87.5*scale,576*scale,175*scale)
    elif proj==(1,2):
     cx,cy=xy([x,y,288]);c.rect(cx-87.5*scale,cy-288*scale,175*scale,576*scale)
 return xy
# Sheet 1 side, clear large
page(1,'Общий вид сбоку / посадка и база')
s=.29;ox=100;oy=170;xy=render((0,2),ox,oy,s,tyres=True)
line(ox-30,oy,ox+3100*s,oy,gray,.6)
for x in [350,2550]:line(ox+x*s,oy-30,ox+x*s,oy+650*s,gray,.5,[4,3])
dimh(ox+350*s,ox+2550*s,oy-35,oy,'2200 — колёсная база')
dimh(ox,ox+3000*s,oy-68,oy+350*s,'3000 — длина рамы по осям')
dimv(oy,oy+1750*s,ox+3100*s,ox+2050*s,'1750 по оси дуги / 1773 с трубой')
dimv(oy,oy+350*s,ox-35,ox,'350 — ось нижней рамы')
# seat and person schematic
for a,b in [((1380,530),(1830,530)),((1830,530),(1950,1240))]:
 x,y=xy((a[0],0,a[1]));xx,yy=xy((b[0],0,b[1]));line(x,y,xx,yy,gray,5)
body=[(750,440),(1020,730),(1600,600),(1830,1150),(1880,1440)]
for a,b in zip(body,body[1:]):
 x,y=xy((a[0],0,a[1]));xx,yy=xy((b[0],0,b[1]));line(x,y,xx,yy,HexColor('#468a7d'),3)
x,y=xy((1880,0,1480));c.setStrokeColor(HexColor('#468a7d'));c.ellipse(x-70*s,y-100*s,x+70*s,y+100*s)
text(ox+1120*s,oy+1800*s,'Силуэт — проверка посадки на макете, не точная антропометрия',8)
text(ox+2100*s,oy+950*s,'ДВС + трансмиссия',9);text(ox+2140*s,oy+880*s,'габариты уточнить',8)
text(ox+2320*s,oy+160*s,'ЦЕЛЬНЫЙ МОСТ',8)
c.showPage()
# sheet 2 plan
page(2,'Вид сверху / два места / ширина')
s=.29;ox=100;oy=390;xy=render((0,1),ox,oy,s,tyres=True)
line(ox-15,oy,ox+3050*s,oy,gray,.5,[5,4])
for y in [-320,320]:
 c.setStrokeColor(gray);c.rect(ox+1380*s,oy+(y-240)*s,500*s,480*s);text(ox+1470*s,oy+y*s,'80 кг',11)
 text(ox+1420*s,oy+(y-80)*s,'до 190 см',8)
dimh(ox,ox+3000*s,oy-880*s,oy-650*s,'3000')
for a,b,label in [(0,650,'650'),(650,900,'250'),(900,2050,'1150'),(2050,2300,'250'),(2300,3000,'700')]:dimh(ox+a*s,ox+b*s,oy+880*s,oy+650*s,label)
dimv(oy-650*s,oy+650*s,ox+1800*s,ox+2050*s,'1300 — кабина по осям')
dimv(oy-700*s,oy+700*s,ox-35,ox+350*s,'1400 — колея спереди*')
dimv(oy-650*s,oy+650*s,ox+3100*s,ox+2550*s,'1300 — колея сзади*')
text(70,115,'* Колеи приняты для компоновки. Заднюю измерить с реальными дисками и шинами. Переднюю согласовать с донорской подвеской.',9)
text(70,95,'Размер шин в модели: Ø576 × 175. Максимальная ширина по передним шинам: 1575. Кабина с трубой: 1340.',9)
c.showPage()
# sheet3 bottom coordinates
page(3,'Нижняя рама / разметка стапеля', 'Плоская часть Z=350. Задние лонжероны Z=550; переход начинается в X=2050.')
s=.28;ox=100;oy=390;xy=render((0,1),ox,oy,s,groups=['40x40x2'],labels=True)
for x in [0,500,650,900,1450,1850,2050,2300,2900,3000]:
 line(ox+x*s,oy-700*s,ox+x*s,oy+700*s,gray,.3,[2,4]);text(ox+x*s-12,oy+730*s,x,7)
for y in [-650,-400,-350,0,350,400,650]:
 line(ox-10,oy+y*s,ox+3020*s,oy+y*s,gray,.3,[2,4]);text(50,oy+y*s-3,y,7)
text(70,150,'Начало координат O=(0,0,0) на земле; X — от носа назад, Y — поперёк, Z — вверх.',10)
text(70,130,'Для разметки на столе используйте Zстол = Z − 350. Задняя часть поднимается на 200 мм.',9)
text(70,110,f'Контроль кабины 900…2050: диагонали по осям = √(1150² + 1300²) = {math.hypot(1150,1300):.1f} мм.',9)
text(70,90,'Диагонали контролируют геометрию; это не расчёт прочности. Торцы переходных деталей требуют совместной подгонки.',9)
c.showPage()
# sheet 4 front and rear elevations
page(4,'Поперечные сечения / дуга за сиденьями')
s=.29;ox=300;oy=150
# draw just main hoop and diagonal
save=P;P=[p for p in save if p['id'] in ['D01','D05','D07']];xy=render((1,2),ox,oy,s)
P=save
for y in [-320,320]:c.setStrokeColor(gray);c.rect(ox+(y-240)*s,oy+470*s,480*s,650*s);text(ox+(y-160)*s,oy+600*s,'Сиденье ≤480',8)
dimh(ox-650*s,ox+650*s,oy-30,oy+370*s,'1300 по оси / 1345 с трубой Ø45')
dimv(oy+370*s,oy+1750*s,ox+720*s,ox+650*s,'1380 — высота дуги от её ног')
text(ox-190,oy+1800*s,'D01: вид сзади; плоскость X=2050',11)
text(650,650,'Кабина для двух взрослых',16)
for i,t in enumerate(['Оси сидений: Y = −320 и +320.','Ширина каждой подушки: до 480.','Между подушками: 160.','Полезная ширина между нижними','лонжеронами: 1260.','Высоту поперечины D07 уточнить','по сиденьям и инструкции ремней.','Сиденья и ремни крепить к силовым','узлам; обшивка не является опорой.','Верх шлема проверять под крышей','и при наклоне головы к боковой дуге.']):text(650,615-i*25,t,11)
c.showPage()
# sheet5 bends developed bars
page(5,'Гибка двух цельных дуг / длина развёртки')
for idx,p in enumerate([x for x in P if x['kind']=='hoop']):
 yy=H-150-idx*300;R=p['R'];L=p['H']-R;B=1300-2*R;arc=math.pi*R/2
 text(65,yy,p['id']+' — '+p['name'],16)
 text(65,yy-27,f"Плоскость: низ {p['base']}, верх {p['top']}; ширина по осям 1300",9)
 text(65,yy-49,f"Rось = 150; 2 гиба × 90°; прямой участок ноги = {L:.2f}; верх = {B}; дуга гиба = {arc:.2f}",10)
 text(65,yy-72,f"Lразв = 2×{L:.2f} + π×150 + 1000 = {p['length']:.2f} мм; заготовка {p['blank']} мм.",11)
 marks=[0,L,L+arc,L+arc+B,L+2*arc+B,2*L+2*arc+B];x0=100;scale=.235;y0=yy-125
 line(x0,y0,x0+marks[-1]*scale,y0,orange,5)
 for m in marks:
  line(x0+m*scale,y0-8,x0+m*scale,y0+12,blue,.6);text(x0+m*scale-12,y0-27,f'{m:.1f}',7)
 text(65,yy-175,'Отметки показаны от чистового торца. При симметричном припуске добавьте половину избытка заготовки.',9)
 text(65,yy-196,'Это геометрические касательные гиба, НЕ установочные метки станка. Смещение и пружинение — по пробному гибу.',9)
text(65,90,'Труба Ø45×3, бесшовная, материал и гибкость подтвердить сертификатом. Прямые сварные углы не заменяют цельную дугу.',9)
c.showPage()
# sheet6 stock layout
page(6,'Карта раскроя хлыстов 6000 мм', 'Заготовки с припусками. Пропил 3 мм на деталь; обрезка торцов хлыста 10 + 10 мм.')
y=H-117;byid={p['id']:p for p in P}
for sec,bs in S['bins'].items():
 text(55,y,sec,12);y-=21
 for i,b in enumerate(bs,1):
  x=145;scale=.143;line(x,y,x+6000*scale,y,gray,14)
  for id in b['parts']:
   p=byid[id];w=p['blank']*scale;c.setFillColor(HexColor('#f4cd8c'));c.rect(x,y-6,w,12,fill=1,stroke=0);
   if w<47:
    c.saveState();c.translate(x+4,y+11);c.rotate(60);text(0,0,id+':'+str(p['blank']),5.5);c.restoreState()
   else:text(x+2,y+11,id+':'+str(p['blank']),6.3)
   x+=w+3*scale
  text(55,y-2,f'Хлыст {i}',8);text(1025,y-3,'ост. '+str(b['remaining']),7);y-=44
 y-=10
text(55,95,'Остатки пригодны для пробных резов и макетов. Окончательные кронштейны подвески в эти 60 м не включены.',9)
c.showPage()
# sheet7 joint example, axle details list
page(7,'Стыки / обмер заднего моста / контроль')
text(60,700,'Пример поперечины A13',15)
# illustrative wide member cross plan
x=70;y=570;sc=.37
for xx in [x,x+1300*sc]:c.setStrokeColor(blue);c.rect(xx-20*sc,y-85,40*sc,170)
c.rect(x+20*sc,y-20*sc,1260*sc,40*sc)
dimh(x,x+1300*sc,y+110,y+85,'1300 — между осями лонжеронов')
dimh(x+20*sc,x+1280*sc,y-110,y-20*sc,'1260 — торец–торец A13')
text(60,410,'1260 = 1300 − 20 − 20. Торцы 90°. Подготовка и зазор — по технологии сварки.',8)
text(660,700,'Обмер моста перед креплениями',15)
for i,t in enumerate(['1. Ширина между привалочными плоскостями колёс.','2. Вылет дисков, фактическая колея и ширина шин.','3. Диаметр / форма чулков и размеры редуктора.','4. Координаты всех штатных кронштейнов тяг.','5. Координаты оси и фланца ведущей шестерни.','6. Передаточное число и направление вращения.','7. Ход подвески, отбойники, тормозные штуцеры.','8. Разболтовка, ступичные посадки, состояние тормозов.']):text(660,665-i*27,t,9)
text(60,330,'Что в этой версии нельзя переносить в металл без уточнения',15)
for i,t in enumerate(['Кронштейны рычагов и амортизаторов, положение рейки, пальцы поворотных кулаков и крепления ремней.', 'Трансмиссия показана габаритно: положения валов, натяжение ремня и кардан требуют отдельной компоновки.', 'Макет заднего хода: +80 / −60 мм от положения модели; это проверяемое предположение, не назначенный рабочий ход.', 'Детали 3D пересекаются в узлах до подрезки. STEP содержит отдельные трубы; сварные швы и разделка не моделированы.', 'Перед выпуском рабочих чертежей нужны расчёт рамы/дуг и креплений, проверка кинематики и тормозов.']):text(60,295-i*33,t,9)
text(60,95,'Карту всех 59 деталей и координаты смотрите в 03_specification.xlsx / cut_list.csv. Разметка в DXF выполнена 1:1 в мм.',9)
c.showPage();c.save()
# DXF axis layout with real physical crosssections omitted; independent views offset.
doc=ezdxf.new('R2010');doc.units=4;m=doc.modelspace()
for layer,col in [('FRAME',30),('CAGE',2),('SECONDARY',4),('LABEL',7),('WHEELS',8),('DIM',3)]:doc.layers.new(layer,dxfattribs={'color':col})
for proj,off,title in [((0,1),(0,0),'TOP / MM / CENTRELINES'),((0,2),(0,2400),'SIDE / MM / CENTRELINES'),((1,2),(4800,0),'REAR / MM / CENTRELINES')]:
 m.add_text(title,height=70,dxfattribs={'layer':'LABEL'}).set_placement((off[0],off[1]-1100 if proj==(0,1) else off[1]-300))
 for p in P:
  ps=p.get('path',[p['a'],p['b']]);layer='CAGE' if p['section']=='45x3' else ('FRAME' if p['section']=='40x40x2' else 'SECONDARY')
  pts=[(a[proj[0]]+off[0],a[proj[1]]+off[1]) for a in ps];m.add_lwpolyline(pts,dxfattribs={'layer':layer})
  if p['kind']=='straight':m.add_text(p['id'],height=27,dxfattribs={'layer':'LABEL'}).set_placement(((pts[0][0]+pts[-1][0])/2+12,(pts[0][1]+pts[-1][1])/2+12))
# explicit chain dims in plan
for a,b in [(0,650),(650,900),(900,2050),(2050,2300),(2300,3000),(0,3000)]:
 d=m.add_linear_dim(base=(0,-900 if (a,b)!=(0,3000) else -1100),p1=(a,0),p2=(b,0),dimstyle='EZDXF',override={'dimtxt':45,'dimasz':30,'dimclrd':3,'dimclre':3});d.render()
doc.saveas(O/'frame_axes_mm.dxf')
print('A3 PDF and DXF ready')
